package com.example.ultraparry;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.UUID;

public class ParryHandler {
    private static final String PARRY_START = "ultraparry_start";
    private static final String PARRY_UNTIL = "ultraparry_until";
    private static final String COOLDOWN_UNTIL = "ultraparry_cooldown";
    private static final String STYLE_CHAIN = "ultraparry_style_chain";
    private static final String STYLE_UNTIL = "ultraparry_style_until";

    // Five-hit combo tracker. The streak is tied to one target and expires after 4 seconds.
    private static final String HIT_TARGET = "ultraparry_hit_target";
    private static final String HIT_COUNT = "ultraparry_hit_count";
    private static final String HIT_LAST = "ultraparry_hit_last";

    private static final int PARRY_WINDOW = 10;       // 0.5 seconds
    private static final int PERFECT_WINDOW = 3;      // first 0.15 seconds
    private static final int COOLDOWN = 16;           // 0.8 seconds
    private static final int COMBO_TIMEOUT = 100;     // 5 seconds
    private static final int HIT_STREAK_TIMEOUT = 80; // 4 seconds
    private static final int HIT_STREAK_REQUIRED = 5;

    @SubscribeEvent
    public void onRightClick(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        if (player.level().isClientSide) return;

        long now = player.level().getGameTime();
        if (now < player.getPersistentData().getLong(COOLDOWN_UNTIL)) return;

        startParry(player, PARRY_WINDOW, "§bPARRY!");
        player.getPersistentData().putLong(COOLDOWN_UNTIL, now + COOLDOWN);
    }

    /**
     * Count successful player hits. Five consecutive hits on the SAME living target
     * automatically trigger a special hit-streak parry, so no right-click is needed.
     */
    @SubscribeEvent
    public void onPlayerHitMob(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player)) return;
        if (player.level().isClientSide || !event.getEntity().isAlive()) return;
        if (event.getEntity() == player || event.getEntity() instanceof Player) return;

        LivingEntity target = event.getEntity();
        long now = player.level().getGameTime();
        var data = player.getPersistentData();
        String targetId = target.getUUID().toString();

        String previousTarget = data.getString(HIT_TARGET);
        long lastHit = data.getLong(HIT_LAST);
        int count = data.getInt(HIT_COUNT);

        if (!targetId.equals(previousTarget) || now - lastHit > HIT_STREAK_TIMEOUT) {
            count = 0;
        }

        count++;
        data.putString(HIT_TARGET, targetId);
        data.putInt(HIT_COUNT, count);
        data.putLong(HIT_LAST, now);

        if (count < HIT_STREAK_REQUIRED) {
            player.displayClientMessage(Component.literal("§cHIT STREAK §f" + count + "§7/5"), true);
            return;
        }

        // Reset the streak immediately, allowing another five-hit chain afterwards.
        data.putInt(HIT_COUNT, 0);
        data.putString(HIT_TARGET, "");
        data.putLong(HIT_LAST, 0L);

        // The fifth strike activates a longer parry window and a burst around the target.
        startParry(player, 14, "§6✦ FIVE-HIT PARRY! §eRIPOSTE READY");
        data.putLong(COOLDOWN_UNTIL, now + COOLDOWN);

        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 35, 3));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, 1));
        // The fifth hit itself is the finisher; avoid applying another player-sourced hit here.
        // Reward the combo with a small heal, momentum and a close-range impact burst.
        player.heal(2.0F);
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 1));
        Vec3 forward = player.getLookAngle().normalize();
        player.push(forward.x * 0.45D, 0.28D, forward.z * 0.45D);
        player.hurtMarked = true;
        shockwave(player, 3.5D, 3.0F, 0.85D);

        if (player.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.FLASH,
                    target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(),
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
            server.sendParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY() + 0.8D, target.getZ(),
                    24, 0.45D, 0.45D, 0.45D, 0.18D);
        }

        player.level().playSound(null, player.blockPosition(),
                net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_IMPACT,
                net.minecraft.sounds.SoundSource.PLAYERS, 0.8F, 1.7F);
    }

    private void startParry(Player player, int duration, String message) {
        long now = player.level().getGameTime();
        var data = player.getPersistentData();
        data.putLong(PARRY_START, now);
        data.putLong(PARRY_UNTIL, now + duration);
        player.displayClientMessage(Component.literal(message), true);
        player.level().playSound(null, player.blockPosition(),
                net.minecraft.sounds.SoundEvents.SHIELD_BLOCK,
                net.minecraft.sounds.SoundSource.PLAYERS, 0.65F, 1.65F);
        if (player.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.ENCHANT,
                    player.getX(), player.getY() + 1.0D, player.getZ(),
                    14, 0.45D, 0.55D, 0.45D, 0.8D);
        }
    }

    private boolean isParrying(Player player) {
        return player.level().getGameTime()
                <= player.getPersistentData().getLong(PARRY_UNTIL);
    }

    private boolean isPerfect(Player player) {
        long now = player.level().getGameTime();
        long start = player.getPersistentData().getLong(PARRY_START);
        return now - start <= PERFECT_WINDOW;
    }

    @SubscribeEvent
    public void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof Player player) || !isParrying(player)) return;
        if (!(event.getProjectile() instanceof Projectile projectile)) return;

        boolean perfect = isPerfect(player);
        double multiplier = perfect ? 2.5D : 1.7D;
        double speed = Math.max(1.2D, projectile.getDeltaMovement().length()) * multiplier;

        projectile.setOwner(player);
        projectile.setDeltaMovement(player.getLookAngle().normalize().scale(speed));
        projectile.hasImpulse = true;
        projectile.setPos(player.getX(), player.getEyeY() - 0.15D, player.getZ());
        event.setCanceled(true);

        successfulParry(player, perfect, "PROJECTILE REFLECTED");
        if (perfect) shockwave(player, 2.8D, 3.0F, 0.8D);

        player.level().playSound(null, player.blockPosition(),
                perfect ? net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_IMPACT
                        : net.minecraft.sounds.SoundEvents.ANVIL_LAND,
                net.minecraft.sounds.SoundSource.PLAYERS, 0.55F, perfect ? 1.8F : 1.45F);
    }

    @SubscribeEvent
    public void onMeleeHit(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player) || !isParrying(player)) return;

        Entity source = event.getSource().getEntity();
        if (!(source instanceof LivingEntity attacker) || attacker == player) return;

        boolean perfect = isPerfect(player);
        event.setCanceled(true);

        attacker.hurt(player.damageSources().playerAttack(player), perfect ? 9.0F : 5.0F);
        Vec3 push = attacker.position().subtract(player.position()).normalize()
                .scale(perfect ? 1.45D : 0.95D);
        attacker.push(push.x, perfect ? 0.6D : 0.35D, push.z);
        attacker.hurtMarked = true;

        successfulParry(player, perfect, perfect ? "PERFECT COUNTER" : "COUNTER");
        if (perfect) shockwave(player, 3.2D, 4.0F, 1.0D);

        player.level().playSound(null, player.blockPosition(),
                net.minecraft.sounds.SoundEvents.SHIELD_BLOCK,
                net.minecraft.sounds.SoundSource.PLAYERS, 0.7F, perfect ? 2.0F : 1.45F);
    }

    private void successfulParry(Player player, boolean perfect, String message) {
        long now = player.level().getGameTime();
        var data = player.getPersistentData();

        int chain = data.getLong(STYLE_UNTIL) >= now ? data.getInt(STYLE_CHAIN) + 1 : 1;
        data.putInt(STYLE_CHAIN, chain);
        data.putLong(STYLE_UNTIL, now + COMBO_TIMEOUT);

        if (perfect) {
            player.heal(1.0F);
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0));
            if (!player.onGround()) {
                Vec3 look = player.getLookAngle();
                player.push(look.x * 0.4D, 0.6D, look.z * 0.4D);
                player.fallDistance = 0.0F;
            }
            player.displayClientMessage(Component.literal("§6✦ PERFECT PARRY! §e" + message), true);
        } else {
            player.displayClientMessage(Component.literal("§b" + message), true);
        }

        if (chain >= 3) {
            data.putInt(STYLE_CHAIN, 0);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 120, 0));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 120, 1));
            player.heal(2.0F);
            player.displayClientMessage(Component.literal("§dSTYLE RANK UP! §f×3 PARRY CHAIN — OVERDRIVE!"), false);
            player.level().playSound(null, player.blockPosition(),
                    net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP,
                    net.minecraft.sounds.SoundSource.PLAYERS, 0.8F, 1.5F);
        }

        if (player.level() instanceof ServerLevel server) {
            server.sendParticles(perfect ? ParticleTypes.CRIT : ParticleTypes.SWEEP_ATTACK,
                    player.getX(), player.getY() + 1.0D, player.getZ(),
                    perfect ? 20 : 9, 0.45D, 0.5D, 0.45D, 0.12D);
        }
    }

    private void shockwave(Player player, double radius, float damage, double knockback) {
        AABB area = player.getBoundingBox().inflate(radius);
        List<LivingEntity> targets = player.level().getEntitiesOfClass(
                LivingEntity.class, area,
                target -> target != player && target.isAlive() && !player.isAlliedTo(target));

        for (LivingEntity target : targets) {
            target.hurt(player.damageSources().playerAttack(player), damage);
            Vec3 away = target.position().subtract(player.position()).normalize().scale(knockback);
            target.push(away.x, 0.35D, away.z);
            target.hurtMarked = true;
        }

        if (player.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.EXPLOSION,
                    player.getX(), player.getY() + 0.8D, player.getZ(),
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
            server.sendParticles(ParticleTypes.CRIT,
                    player.getX(), player.getY() + 0.8D, player.getZ(),
                    30, radius / 2.0D, 0.3D, radius / 2.0D, 0.18D);
        }
    }
}
