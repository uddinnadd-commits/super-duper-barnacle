package com.example.ultraparry;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(UltraParry.MODID)
public class UltraParry {
    public static final String MODID = "ultraparry";

    public UltraParry() {
        MinecraftForge.EVENT_BUS.register(new ParryHandler());
    }
}
