# UltraParry Ultimate — Forge 1.20.1

An expanded ULTRAKILL-inspired combat mod for Minecraft Forge 1.20.1.

## Mechanics

### Manual parry
- Right-click with any item or an empty hand.
- 10-tick (0.5 second) parry window, with a 3-tick perfect window.
- 16-tick (0.8 second) cooldown.
- Perfect parries heal, boost movement, and give an aerial recovery impulse.

### Five-hit mob combo parry (NEW)
- Hit the **same living mob five times in a row**.
- The action bar tracks the streak: `HIT STREAK 1/5` through `5/5`.
- Hits must land within 4 seconds of one another.
- The fifth hit automatically triggers a special 14-tick parry window. No right-click is needed.
- The fifth strike also hits the target with a bonus burst, slows and weakens it, heals you, gives a speed boost, and releases a close-range shockwave.
- The counter resets after the fifth hit; build another five-hit streak to trigger it again.
- Hitting a different target or letting the 4-second timer expire resets the streak.

### Counters and style
- Projectiles are reflected toward your look direction (1.7x speed, or 2.5x on a perfect parry).
- Melee hits during a parry are canceled and counter the attacker.
- Perfect parries unleash a shockwave.
- Three successful parries within 5 seconds trigger Overdrive: Strength, Speed and healing.
- Particles, sound cues and action-bar callouts provide combat feedback.

## Build and install
1. Install Java 17 and a compatible Gradle 8.x installation.
2. Open this project in IntelliJ IDEA or Eclipse, or run `gradle build`.
3. The compiled mod JAR is generated in `build/libs/`.
4. Put the JAR in your Minecraft `mods` folder with Minecraft Forge **1.20.1 (47.x)**.

This ZIP contains the source project rather than a precompiled JAR. ForgeGradle downloads the required Forge dependencies during the first build.

## GitHub Actions build
A workflow is included at `.github/workflows/build.yml`. It pins the CI runtime to
Java 17 and does not run any migration or automatic version-upgrade task. The
workflow uses Gradle offline mode; this only succeeds when the required Gradle
and Forge dependencies are already cached on the runner. For a first-time GitHub
Actions build, remove `--offline` from the build command so Gradle can download
those dependencies.
